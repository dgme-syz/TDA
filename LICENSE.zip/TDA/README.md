# TDA
A simple implementation of the original paper [Efficient Test-Time Adaptation of Vision-Language Models](https://arxiv.org/abs/2403.18293).
